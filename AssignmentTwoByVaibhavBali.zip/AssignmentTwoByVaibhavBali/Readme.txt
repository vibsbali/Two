This Assignment is created by Vaibhav Bali 
Student Number 01086800

The Problems/Questions are solved in seperate R files and are titled
1. QuestionOne
2. QuestionTwo
3. QuestionThree

Charts are also going to be handed in via paper format in class